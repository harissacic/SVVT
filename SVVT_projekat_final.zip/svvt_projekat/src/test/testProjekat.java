package test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

class testProjekat {
	
	private static WebDriver webDriver;
	private static String baseUrl;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\Desktop\\chromedriver\\chromedriver.exe");
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");
		
		
		
		webDriver = new ChromeDriver(options);
		baseUrl = "https://www.mojbrend.ba/";
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		webDriver.quit();
	}

	@Test
	void testRegistration() throws InterruptedException {
		webDriver.get(baseUrl);
		
		webDriver.findElement(By.xpath("//*[@id=\"pageheader\"]/div[1]/div[3]/div/a[1]")).click();
		webDriver.findElement(By.xpath("//*[@id=\"customer_login\"]/div[3]/div/a")).click();
		Thread.sleep(2000);
		
		webDriver.findElement(By.id("first_name")).sendKeys("Nadja");
		webDriver.findElement(By.id("last_name")).sendKeys("Cizmic");
		webDriver.findElement(By.id("email")).sendKeys("nadjacizmic@hotmail.com");
		webDriver.findElement(By.id("password")).sendKeys("Lozinka123");
		webDriver.findElement(By.xpath("//*[@id=\"create_customer\"]/div[5]/button")).click();
		Thread.sleep(2000);
		
		String url = webDriver.getCurrentUrl();
		assertEquals("https://www.mojbrend.ba/account/register",url);
		webDriver.navigate().to("https://www.mojbrend.ba/");
		Thread.sleep(3000);
	}
	
	//login, povratak na kupovinu, odjava
	@Test	
	void testLogin() throws InterruptedException {
		webDriver.get(baseUrl);
		
		webDriver.findElement(By.xpath("//*[@id=\"pageheader\"]/div[1]/div[3]/div/a[1]/span[1]")).click();
		webDriver.findElement(By.id("customer_email")).sendKeys("nadjacizmic@hotmail.com");
		webDriver.findElement(By.id("customer_password")).sendKeys("Lozinka123");
		Thread.sleep(5000);
		webDriver.findElement(By.xpath("//*[@id=\"customer_login\"]/div[3]/div/button")).click();
		Thread.sleep(5000);
		WebElement ime = webDriver.findElement(By.xpath("//*[@id=\"customer_detail\"]/h5"));
		assertEquals("Nadja Cizmic", ime.getText());
		Thread.sleep(2000);
		
		webDriver.findElement(By.xpath("//*[@id=\"return_to_store\"]/a[1]")).click();
		Thread.sleep(2000);
		webDriver.navigate().back();
		Thread.sleep(2000);
		
		webDriver.findElement(By.xpath("//*[@id=\"return_to_store\"]/a[2]")).click();
		Thread.sleep(2000);	
	}
	
	@Test
	void testSearch() throws InterruptedException {
		webDriver.get(baseUrl);
		
		webDriver.findElement(By.xpath("//*[@id=\"pageheader\"]/div[1]/div[1]/div/a")).click();
		Thread.sleep(3000);
		webDriver.findElement(By.name("q")).sendKeys("Tommy Hilfiger");
		webDriver.findElement(By.xpath("//*[@id=\"main-search\"]/div/form/button")).click();
		Thread.sleep(3000);
		webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664688001272__main\"]/div/div[2]/div[3]/div[2]/div/div[1]/div/div/a")).click();
		Thread.sleep(5000);
		webDriver.navigate().back();
		
		webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664688001272__main\"]/div/div[2]/div[1]/div[3]/span[1]/div/button")).click();
		webDriver.findElement(By.xpath("//*[@id=\"sort-dropdown-options\"]/a[2]")).click();
		Thread.sleep(3000);
		webDriver.navigate().back();
		Thread.sleep(3000);
	}
	
	//Calvin Klein, Tommy Hilffiger, Replay	
	@Test
	void testGoingBack() throws InterruptedException {
		webDriver.get(baseUrl);
		webDriver.findElement(By.xpath("//*[@id=\"main-nav\"]/div/div/ul/li[1]/a[1]")).click();
		Thread.sleep(2000);
		WebElement title1= webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664682463480__main\"]/div/div[1]/div/h1"));
		assertEquals("Calvin Klein �enski i mu�ki proizvodi", title1.getText());
		Thread.sleep(2000);
		webDriver.navigate().back();
		Thread.sleep(2000);
		
		webDriver.findElement(By.xpath("//*[@id=\"main-nav\"]/div/div/ul/li[2]/a[1]")).click();
		Thread.sleep(2000);
		WebElement title2= webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664685052152__main\"]/div/div[1]/div/h1"));
		assertEquals("Tommy Hilfiger �enski i mu�ki proizvodi", title2.getText());
		Thread.sleep(2000);
		webDriver.navigate().back();
		Thread.sleep(2000);
		
		webDriver.findElement(By.xpath("//*[@id=\"main-nav\"]/div/div/ul/li[3]/a[1]")).click();
		Thread.sleep(2000);
		WebElement title3= webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664683774200__main\"]/div/div[1]/div/h1"));
		assertEquals("Replay �enski i mu�ki proizvodi", title3.getText());
		Thread.sleep(2000);
		webDriver.navigate().back();
		Thread.sleep(2000);
		
		webDriver.findElement(By.xpath("//*[@id=\"main-nav\"]/div/div/ul/li[4]/a[1]")).click();
		Thread.sleep(2000);
		WebElement title4= webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664686985464__main\"]/div/div[1]/div/h1"));
		assertEquals("U.S. Polo Assn. �enski i mu�ki proizvodi", title4.getText());
		Thread.sleep(2000);
		webDriver.navigate().back();
		Thread.sleep(2000);
		
	}
	
//	Prijava na newsletter
	@Test
	void testNewsletter() throws InterruptedException {
		webDriver.get(baseUrl);
	
		WebElement newsletterTitle = webDriver.findElement(By.xpath("//*[@id=\"shopify-section-footer\"]/div/div[1]/div/div[3]/h6"));
		assertEquals("�ELIM BITI U TRENDU!",newsletterTitle.getText());
		
		
		webDriver.findElement(By.name("contact[email]")).sendKeys("nadjacizmic@hotmail.com");
		Thread.sleep(2000);
		webDriver.findElement(By.xpath("//*[@id=\"footer_newsletter_signup\"]/button")).click();
	}
	
	@Test
	void testKorpa() throws InterruptedException {
		webDriver.get(baseUrl);
		webDriver.findElement(By.xpath("//*[@id=\"pageheader\"]/div[1]/div[3]/div/a[1]/span[1]")).click();
		webDriver.findElement(By.id("customer_email")).sendKeys("nadjacizmic@hotmail.com");
		webDriver.findElement(By.id("customer_password")).sendKeys("Lozinka123");
		Thread.sleep(2000);
		webDriver.findElement(By.xpath("//*[@id=\"customer_login\"]/div[3]/div/button")).click();
		Thread.sleep(2000);		
		webDriver.findElement(By.xpath("//*[@id=\"return_to_store\"]/a[1]")).click();
		Thread.sleep(2000);
		webDriver.findElement(By.xpath("//*[@id=\"main-nav\"]/div/div/ul/li[1]/a[1]")).click();
		Thread.sleep(2000);
		webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664682463480__main\"]/div/div[2]/div[3]/div[2]/div/div[1]/div/div/div[1]/a[1]")).click();
		webDriver.findElement(By.xpath("//*[@id=\"product-form-template--16664687575288__main-7897031934200\"]/div/div[1]/button")).click();
		Thread.sleep(2000);		
		webDriver.findElement(By.xpath("//*[@id=\"shopify-section-cart-drawer\"]/div/div[3]/a[1]")).click();
		webDriver.navigate().back();
		Thread.sleep(2000);		
		webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664682463480__main\"]/div/div[2]/div[3]/div[2]/div/div[6]/div/div/div[1]/a[1]")).click();
		webDriver.findElement(By.xpath("//*[@id=\"product-form-template--16664687575288__main-7890992103672\"]/div/div[1]/button")).click();
		Thread.sleep(2000);
		webDriver.findElement(By.xpath("//*[@id=\"shopify-section-cart-drawer\"]/div/div[3]/a[2]")).click();
		Thread.sleep(2000);		
		WebElement cart = webDriver.findElement(By.xpath("//*[@id=\"pageheader\"]/div[1]/div[3]/div/a[3]/span[2]/span"));
		assertEquals("2", cart.getText());
		Thread.sleep(2000);		
	}
	
	@Test
	void testKupiOdmahKorpa() throws InterruptedException {
		webDriver.get(baseUrl);
		
		webDriver.findElement(By.xpath("//*[@id=\"pageheader\"]/div[1]/div[3]/div/a[1]/span[1]")).click();
		webDriver.findElement(By.id("customer_email")).sendKeys("nadjacizmic@hotmail.com");
		webDriver.findElement(By.id("customer_password")).sendKeys("Lozinka123");
		Thread.sleep(2000);
		webDriver.findElement(By.xpath("//*[@id=\"customer_login\"]/div[3]/div/button")).click();
		Thread.sleep(2000);		
		webDriver.findElement(By.xpath("//*[@id=\"return_to_store\"]/a[1]")).click();
		Thread.sleep(2000);
		
		webDriver.findElement(By.xpath("//*[@id=\"main-nav\"]/div/div/ul/li[2]/a[1]")).click();
		webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664685052152__main\"]/div/div[2]/div[3]/div[2]/div/div[6]/div/div/div[1]/a[1]")).click();
		webDriver.findElement(By.xpath("//*[@id=\"product-form-template--16664687837432__main-7890990727416\"]/div/div[2]/div/div/div/button[1]")).click();
		Thread.sleep(2000);
		//koristi novu adresu
		Select adresa = new Select(webDriver.findElement(By.id("Select0")));
		adresa.selectByIndex(1);
		Thread.sleep(2000);
		Select drzava = new Select(webDriver.findElement(By.name("countryCode")));
		adresa.selectByIndex(0);
		Thread.sleep(2000);
		
		webDriver.findElement(By.name("firstName")).sendKeys("Haris");
		webDriver.findElement(By.name("lastName")).sendKeys("Sacic");
		webDriver.findElement(By.name("address1")).sendKeys("Tekija 56");
		webDriver.findElement(By.name("postalCode")).sendKeys("71000");
		webDriver.findElement(By.name("city")).sendKeys("Sarajevo");
		webDriver.findElement(By.name("phone_field")).sendKeys("061123456");
		Thread.sleep(3000);
		webDriver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[1]/div/div[2]/div/div/div/div[2]/div/div/div/main/form/div[1]/div/div/div[2]/div[1]/button")).click();
		Thread.sleep(3000);
	}
	
	@Test
	void testUkloniIzKorpe() throws InterruptedException {
		webDriver.get(baseUrl);	
		webDriver.findElement(By.xpath("//*[@id=\"pageheader\"]/div[1]/div[3]/div/a[1]/span[1]")).click();
		webDriver.findElement(By.id("customer_email")).sendKeys("nadjacizmic@hotmail.com");
		webDriver.findElement(By.id("customer_password")).sendKeys("Lozinka123");
		Thread.sleep(2000);
		webDriver.findElement(By.xpath("//*[@id=\"customer_login\"]/div[3]/div/button")).click();
		Thread.sleep(2000);		
		webDriver.findElement(By.xpath("//*[@id=\"return_to_store\"]/a[1]")).click();
		Thread.sleep(2000);	
		webDriver.findElement(By.xpath("//*[@id=\"main-nav\"]/div/div/ul/li[2]/a[1]")).click();
		webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664685052152__main\"]/div/div[2]/div[3]/div[2]/div/div[6]/div/div/div[1]/a[1]")).click();	
		Thread.sleep(2000);		
		webDriver.findElement(By.xpath("/html/body/main/div/div[1]/div/div[2]/div[2]/div/div[6]/form/div/div[1]/button")).click();
		Thread.sleep(2000);
		
		webDriver.findElement(By.linkText("Korpa")).click();
		Thread.sleep(2000);
		
		webDriver.findElement(By.xpath("//*[@id=\"cartform\"]/div[1]/div[2]/div/div[2]/div[3]/a")).click();
		Thread.sleep(2000);
		
		WebElement korpa = webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664682004728__main\"]/div/div[1]/h1"));
		assertEquals("Korpa", korpa.getText());
		Thread.sleep(2000);
		
	}
	
	@Test
	void testZaboravitiSifru() throws InterruptedException {
		webDriver.get("https://www.mojbrend.ba/account/login");
		
		webDriver.findElement(By.id("customer_email")).sendKeys("nadjacizmic@hotmail.com");
		webDriver.findElement(By.linkText("Zaboravili ste �ifru?")).click();
		Thread.sleep(2000);
		
		webDriver.findElement(By.name("email")).sendKeys("nigdjeveze@hotmail.com");
		webDriver.findElement(By.xpath("//*[@id=\"recover-password\"]/form/div[3]/p/button")).click();
		Thread.sleep(3000);
		
		
		webDriver.findElement(By.id("recover-email")).sendKeys("nadjacizmic@hotmail.com");
		Thread.sleep(3000);
		webDriver.findElement(By.xpath("//*[@id=\"recover-password\"]/form/div[4]/span/a")).click();
		Thread.sleep(3000);
		
	}
	@Test
	void testPgresanLogin() throws InterruptedException {
		webDriver.get("https://www.mojbrend.ba/account/login");
		
		webDriver.findElement(By.xpath("//*[@id=\"customer_email\"]")).sendKeys("nidjeveze.gmail.com");
		Thread.sleep(2000);		
		
}
	//brzi linkovi
	@Test
	void testFastLinks() throws InterruptedException {
		webDriver.get(baseUrl);
		
		webDriver.findElement(By.linkText("O nama")).click();
		WebElement title1 = webDriver.findElement(By.className("majortitle"));
		String oNama = title1.getText();
		assertEquals("O nama", oNama);
		Thread.sleep(2000);
		
		webDriver.findElement(By.linkText("Kontakt")).click();
		WebElement title2 = webDriver.findElement(By.className("majortitle"));
		String kontakt = title2.getText();
		assertEquals("Kontakt", kontakt);
		Thread.sleep(2000);

		webDriver.findElement(By.linkText("Politika privatnosti")).click();
		WebElement title3 = webDriver.findElement(By.xpath("//*[@id=\"content\"]/div/div/div[1]/h1"));
		String privatnost = title3.getText();
		assertEquals("Pravila za�tite privatnosti", privatnost);
		
		Thread.sleep(2000);
		
		webDriver.findElement(By.linkText("Op�ti prodajni uslovi")).click();
		WebElement title4 = webDriver.findElement(By.xpath("/html/body/main/div/div/div[1]/h1"));
		assertEquals("Uvjeti pru�anja usluge", title4.getText());
		Thread.sleep(2000);
	}
	

	//filteri	
	@Test
	void testFilter() throws InterruptedException {
		webDriver.get(baseUrl);
		
		
	webDriver.findElement(By.xpath("//*[@id=\"block-id-f76160c3-3823-4639-be1b-4a3a0b21ec0c\"]/div/a/div/div/img")).click();
	Thread.sleep(3000);
	
		webDriver.findElement(By.xpath("//*[@id=\"CollectionFilterForm\"]/li[2]/div/div/label[1]/span")).click();
		Thread.sleep(3000);
		
		WebElement calvin = webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664683118840__main\"]/div/div[2]/div[3]/div[2]/div/div[1]/div/div/div[2]/div/div/a/div[1]"));
		String calvinKlein = calvin.getText();
		assertEquals("CALVIN KLEIN", calvinKlein);
		Thread.sleep(3000);
		
		webDriver.findElement(By.xpath("//*[@id=\"CollectionFilterForm\"]/li[2]/div/div/label[1]/span")).click();
		webDriver.findElement(By.xpath("//*[@id=\"CollectionFilterForm\"]/li[2]/div/div/label[2]/span")).click();
		Thread.sleep(3000);

		WebElement diesel = webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664683118840__main\"]/div/div[2]/div[3]/div[2]/div/div[1]/div/div/div[2]/div/div/a/div[1]"));
		String diesel1 = diesel.getText();
		assertEquals("DIESEL", diesel1);
		Thread.sleep(3000);
		
	}
	
	//size
	@Test
	void testSize() throws InterruptedException {
		webDriver.get(baseUrl);
		
		
	webDriver.findElement(By.xpath("//*[@id=\"block-id-f76160c3-3823-4639-be1b-4a3a0b21ec0c\"]/div/a/div/div/img")).click();
	Thread.sleep(3000);
	
	webDriver.findElement(By.xpath("/html/body/table/tbody/tr[2668]/td[2]/span[2]")).click();
	Thread.sleep(3000);
	
	webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664683118840__main\"]/div/div[2]/div[3]/div[2]/div/div[1]/div/div/div[2]/div/div/a/div[1]")).click();
	Thread.sleep(3000);
	
	WebElement size = webDriver.findElement(By.xpath("//*[@id=\"shopify-section-template--16664687575288__main\"]/div/div[2]/div[2]/div/div[4]/div/div/fieldset/div[2]/label/span"));
	String sizeS = size.getText();
	assertEquals("S", sizeS);
		
	}
	
	//otherCountries
	@Test
	void testOtherCountries() throws InterruptedException {
		webDriver.get(baseUrl);
		
		webDriver.findElement(By.xpath("//*[@id=\"shopify-section-footer\"]/div/div[1]/div/div[1]/div[1]/p[5]/a")).click();
		Thread.sleep(5000);
		String url = webDriver.getCurrentUrl();
		assertEquals("https://mojbrend.co.rs/", url);
		Thread.sleep(4000);
		
	webDriver.get(baseUrl);
		
		webDriver.findElement(By.linkText("www.mojbrend.hr")).click();
		Thread.sleep(3000);
		String url2 = webDriver.getCurrentUrl();
		assertEquals("https://mojbrend.hr/", url2);
		
		webDriver.get(baseUrl);
		
		webDriver.findElement(By.linkText("www.mojbrend.me")).click();
		Thread.sleep(3000);
		String url3 = webDriver.getCurrentUrl();
		assertEquals("https://mojbrend.me/", url3);
		
	}
	
	//chat
		@Test
		void testChat() throws InterruptedException {
			webDriver.get(baseUrl);
			Thread.sleep(3000);
			webDriver.findElement(By.xpath("//*[@id=\"dummy-chat-button\"]")).click();
			Thread.sleep(3000);
			webDriver.findElement(By.xpath("/html/body/div/div/div/div[2]/button[2]")).click();
			   
			Thread.sleep(3000);
			WebElement message = webDriver.findElement(By.xpath("/html/body/div/div/div/div[2]/div[1]/ul/li[2]/span[2]"));
			String messageContent = message.getText();
			assertEquals("Narud�be", messageContent);
				
			}
	@Test
	void testViseBrendova() throws InterruptedException {
		webDriver.get(baseUrl);
		
		webDriver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div/div/ul/li[5]/a[1]")).click();
		Thread.sleep(3000);
		webDriver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div/div/ul/li[5]/div/div/ul/li[1]/a")).click();
		Thread.sleep(3000);
		
		WebElement diesel = webDriver.findElement(By.xpath("/html/body/main/div/div/div/div[1]/div/h1"));
		assertEquals("Diesel �enski i mu�ki proizvodi", diesel.getText());
		
	}
	
}
